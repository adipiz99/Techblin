package model;

public class InvalidDataException extends RuntimeException{
	private static final long serialVersionUID = 6092417966640936303L;
	
	public InvalidDataException() {
		super();
	}
}
